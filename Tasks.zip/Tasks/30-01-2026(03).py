import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5]
y1 = [10, 20, 30, 40, 50]
y2 = [50, 40, 30, 20, 10]

plt.figure()

plt.plot(x, y1, linestyle='--', label='Increasing')
plt.plot(x, y2, linestyle='-.', label='Decreasing')

plt.title("Line Plot with Legend and Style")
plt.xlabel("X Values")
plt.ylabel("Y Values")

plt.legend()   
plt.grid(True) 

plt.show()

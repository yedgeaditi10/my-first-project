import matplotlib.pyplot as plt

activities = ['Sleeping', 'Studying', 'Playing', 'Others']
hours = [8, 6, 4, 6]

plt.figure()
plt.pie(hours, labels=activities, autopct='%1.1f%%')
plt.title("Daily Activities Distribution")
plt.show()

import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5]
trend1 = [5, 10, 15, 20, 25]
trend2 = [25, 20, 15, 10, 5]
trend3 = [10, 15, 10, 15, 10]

plt.figure()

plt.plot(x, trend1, color='blue', marker='o', label='Trend 1')
plt.plot(x, trend2, color='red', marker='s', label='Trend 2')
plt.plot(x, trend3, color='green', marker='^', label='Trend 3')

plt.title("Multiple Trends")
plt.xlabel("X Axis")
plt.ylabel("Values")

plt.legend()
plt.grid(True)

plt.show()

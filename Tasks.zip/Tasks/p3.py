s1="noon"
s2="noon"

if len(s1) == len(s2) and s2 in(s1+s1):
    print("Rotation")
else:
    print("Not Rotation")
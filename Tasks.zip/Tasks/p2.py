nums = [5, 10, 15, 3, 7, 8, 10, 5]
target = 33

n = len(nums)

for i in range(n):
    current_sum = 0
    for j in range(i, n):
        current_sum += nums[j]
        if current_sum == target:
            print(nums[i:j+1])
